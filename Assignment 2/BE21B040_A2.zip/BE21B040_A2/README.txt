This is a submission by: 

Sumedh Sanjay Kangne | BE21B040
Department of Biotechnology, IIT Madras

Contents:
1. BE21B040_A2_Report.pdf: A detailed report of the Assignment.

2. FitzHughNagumo.m: Code written in Matlab to simulate the FitzHugh-Nagumo Model. Run this code like any normal Matlab function without any parameters.

3. Images: A Folder containing all the images used in the Report.
