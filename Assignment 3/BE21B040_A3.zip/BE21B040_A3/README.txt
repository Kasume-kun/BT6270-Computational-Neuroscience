This is a submission by: 

Sumedh Sanjay Kangne | BE21B040
Department of Biotechnology, IIT Madras

Contents:
1. BE21B040_A3_Report.pdf: A detailed report of the Assignment.

2. complexCoupling.py: Code written in Python to see the complex coupling behavior of Hopf oscillators.

3. powercoupling.py: Code written in Python to see the power coupling behavior of Hopf oscillators.

4. Images: A Folder containing all the images used in the Report.
